const API = 'http://localhost:4000';
async function test(){
  const tests = [
    {msg:"Double sharing price kya hai?", phone:"+919876500001", label:"Pricing Inquiry"},
    {msg:"Location bhejo", phone:"+919876500002", label:"Location Request"},
    {msg:"Meri beti ke liye safe hai? UPSC karti hai", phone:"+919876500003", label:"Parent Enquiry (High Trust)"},
    {msg:"Available hai kya? Kal shift hona hai urgent", phone:"+919876500004", label:"Availability Hot Lead"},
    {msg:"WiFi not working since morning Room 204", phone:"+919876500005", label:"Complaint Auto-Routing"}
  ];
  for(const t of tests){
    console.log(`\n=== TEST: ${t.label} ===`);
    console.log(`User: ${t.msg}`);
    try{
      const res = await fetch(API+'/api/ai/chat', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({message:t.msg, phone:t.phone})});
      const data = await res.json();
      console.log(`Intent: ${data.data.intent} | Confidence: ${data.data.confidence} | Price: ₹${data.data.suggestedPrice} | Model: ${data.debug.model}`);
      console.log(`Priya: ${data.data.response}`);
      console.log(`Lead Score: ${data.lead.aiScore} ${data.lead.isHot?'🔥 HOT':''} | Budget: ${data.lead.budget||'NA'} | Type: ${data.lead.preferredRoomType||'NA'}`);
    }catch(e){ console.error('Failed', e.message); }
  }
  
  console.log(`\n=== DASHBOARD STATS ===`);
  const stats = await (await fetch(API+'/api/dashboard/stats')).json();
  console.log(`Occupancy: ${stats.data.totals.occupancyRate}% | Available: ${stats.data.totals.availableRooms}/${stats.data.totals.rooms} | Hot Leads: ${stats.data.totals.hotLeads} | Revenue Est: ₹${stats.data.revenueEstimate}/mo`);

  console.log(`\n=== COMPLAINT AUTO-ROUTING ===`);
  const comp = await (await fetch(API+'/api/complaints', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({title:"WiFi not working", description:"WiFi not working urgent Room 204", category:"WIFI"})})).json();
  console.log(`Complaint ID: ${comp.data.complaintIdFormatted} | Title: ${comp.data.title} | Priority: ${comp.data.priority} | Assigned: ${comp.data.assignedStaff.name} (${comp.data.assignedStaff.role}) Rating ${comp.data.assignedStaff.rating} | SLA: ${comp.data.message}`);

  console.log(`\n=== DYNAMIC PRICING 13k-15.5k Enforcement ===`);
  for(const type of ['SINGLE','DOUBLE','TRIPLE','FOUR_SHARING']){
    const p = await (await fetch(API+'/api/ai/pricing/calculate', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({roomType:type})})).json();
    console.log(`${type}: Current ₹${p.data.currentPrice} → Suggested ₹${p.data.suggestedPrice} (×${p.data.multiplier}) Reason: ${p.data.reason.slice(0,60)}... Occupancy ${p.data.occupancy}% IN CAP ${p.data.suggestedPrice>=13000 && p.data.suggestedPrice<=15500?'✅ OK':'❌ FAIL'}`);
  }

  console.log(`\n=== WHATSAPP WEBHOOK SIMULATION ===`);
  const wa = await (await fetch(API+'/api/whatsapp/webhook', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({object:"whatsapp_business_account", entry:[{changes:[{value:{messaging_product:"whatsapp", metadata:{phone_number_id:"123"}, messages:[{from:"919876500099", id:"wamid.test123", type:"text", text:{body:"Hi location bhejo"}}]}}]}]})})).json();
  console.log(`Webhook Response: ${JSON.stringify(wa).slice(0,200)}`);
  console.log(`Check logs: Should have [MOCK WHATSAPP] + AI reply with maps link`);
}
test();
